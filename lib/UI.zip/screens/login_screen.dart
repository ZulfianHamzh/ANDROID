import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/pos_provider.dart';
import '../utils/app_theme.dart';
import '../utils/responsive_utils.dart';
import 'register_screen.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;
  bool _isLoading = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();
    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Mohon isi email dan password')),
      );
      return;
    }

    setState(() => _isLoading = true);

    final error = await ref.read(posProvider.notifier).login(email, password);
    if (!mounted) return;

    setState(() => _isLoading = false);

    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error)),
      );
      return;
    }

    ref.read(posProvider.notifier).loadProducts();
  }

  @override
  Widget build(BuildContext context) {
    ResponsiveUtils.init(context);
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: ResponsiveUtils.spaceXLarge),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: ResponsiveUtils.screenHeight * 0.1),
                Container(
                  height: ResponsiveUtils.screenHeight * 0.25,
                  width: ResponsiveUtils.screenWidth * 0.7,
                  decoration: BoxDecoration(
                    color: AppColors.primaryGreen.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(ResponsiveUtils.radiusNormal),
                  ),
                  child: Center(
                    child: Text(
                      'DHBH',
                      style: TextStyle(
                        fontSize: ResponsiveUtils.font3XLarge,
                        fontWeight: FontWeight.bold,
                        color: AppColors.primaryGreen,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: ResponsiveUtils.spaceLarge),
                _buildTextField('Email', controller: _emailController),
                SizedBox(height: ResponsiveUtils.spaceNormal),
                _buildTextField('Password',
                  controller: _passwordController,
                  obscureText: _obscurePassword,
                  suffix: IconButton(
                    icon: Icon(
                      _obscurePassword ? Icons.visibility_off : Icons.visibility,
                      color: Colors.white70,
                      size: ResponsiveUtils.iconSmall,
                    ),
                    onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                  ),
                ),
                SizedBox(height: ResponsiveUtils.spaceLarge),
                SizedBox(
                  width: ResponsiveUtils.buttonHeightLarge * 3,
                  height: ResponsiveUtils.buttonHeightNormal,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _login,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryGreen,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(1000),
                      ),
                      elevation: 8,
                      shadowColor: Colors.black.withValues(alpha: 0.12),
                    ),
                    child: _isLoading
                        ? SizedBox(
                            width: ResponsiveUtils.iconNormal,
                            height: ResponsiveUtils.iconNormal,
                            child: const CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                          )
                        : Text(
                            'Login',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: ResponsiveUtils.fontLarge,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                  ),
                ),
                SizedBox(height: ResponsiveUtils.spaceNormal),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const RegisterScreen()),
                    );
                  },
                  child: Text(
                    'Belum punya akun? Daftar',
                    style: TextStyle(
                      color: AppColors.primaryGreen,
                      fontWeight: FontWeight.w600,
                      fontSize: ResponsiveUtils.fontNormal,
                    ),
                  ),
                ),
                SizedBox(height: ResponsiveUtils.spaceLarge),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String hint, {
    TextEditingController? controller,
    bool obscureText = false,
    Widget? suffix,
  }) {
    return Container(
      constraints: BoxConstraints(maxWidth: 480 * ResponsiveUtils.scaleFactor),
      height: ResponsiveUtils.buttonHeightLarge,
      decoration: BoxDecoration(
        color: AppColors.gray,
        borderRadius: BorderRadius.circular(ResponsiveUtils.radiusNormal),
      ),
      child: TextField(
        controller: controller,
        obscureText: obscureText,
        style: TextStyle(color: Colors.white, fontSize: ResponsiveUtils.fontLarge),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: Colors.white.withValues(alpha: 0.8)),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(
            horizontal: ResponsiveUtils.spaceNormal,
            vertical: ResponsiveUtils.spaceNormal,
          ),
          suffixIcon: suffix,
        ),
      ),
    );
  }
}
