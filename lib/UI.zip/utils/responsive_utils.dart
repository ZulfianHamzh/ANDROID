import 'package:flutter/material.dart';

/// Responsive utilities for 800x1280 (16:10 ratio) 8-inch tablet
class ResponsiveUtils {
  static late MediaQueryData _mediaQuery;
  static late Size _screenSize;

  /// Initialize responsive utilities
  static void init(BuildContext context) {
    _mediaQuery = MediaQuery.of(context);
    _screenSize = _mediaQuery.size;
  }

  /// Screen dimensions
  static double get screenWidth => _screenSize.width;
  static double get screenHeight => _screenSize.height;
  static double get aspectRatio => _screenSize.aspectRatio;

  /// Base scaling factor (1.0 for 800px width)
  static double get scaleFactor {
    return screenWidth / 800;
  }

  /// Responsive padding
  static EdgeInsets get paddingSmall => EdgeInsets.all(8 * scaleFactor);
  static EdgeInsets get paddingNormal => EdgeInsets.all(16 * scaleFactor);
  static EdgeInsets get paddingLarge => EdgeInsets.all(24 * scaleFactor);
  static EdgeInsets get paddingXLarge => EdgeInsets.all(32 * scaleFactor);

  /// Responsive horizontal padding
  static EdgeInsets get paddingHorizontalSmall => 
      EdgeInsets.symmetric(horizontal: 8 * scaleFactor);
  static EdgeInsets get paddingHorizontalNormal => 
      EdgeInsets.symmetric(horizontal: 16 * scaleFactor);
  static EdgeInsets get paddingHorizontalLarge => 
      EdgeInsets.symmetric(horizontal: 24 * scaleFactor);

  /// Responsive vertical padding
  static EdgeInsets get paddingVerticalSmall => 
      EdgeInsets.symmetric(vertical: 8 * scaleFactor);
  static EdgeInsets get paddingVerticalNormal => 
      EdgeInsets.symmetric(vertical: 12 * scaleFactor);
  static EdgeInsets get paddingVerticalLarge => 
      EdgeInsets.symmetric(vertical: 20 * scaleFactor);

  /// Responsive font sizes
  static double get fontXSmall => 10 * scaleFactor;
  static double get fontSmall => 12 * scaleFactor;
  static double get fontNormal => 14 * scaleFactor;
  static double get fontLarge => 16 * scaleFactor;
  static double get fontXLarge => 18 * scaleFactor;
  static double get font2XLarge => 22 * scaleFactor;
  static double get font3XLarge => 28 * scaleFactor;
  static double get fontDisplay => 32 * scaleFactor;

  /// Responsive icon sizes
  static double get iconXSmall => 16 * scaleFactor;
  static double get iconSmall => 20 * scaleFactor;
  static double get iconNormal => 24 * scaleFactor;
  static double get iconLarge => 32 * scaleFactor;
  static double get iconXLarge => 48 * scaleFactor;
  static double get icon2XLarge => 64 * scaleFactor;

  /// Responsive button heights
  static double get buttonHeightSmall => 36 * scaleFactor;
  static double get buttonHeightNormal => 44 * scaleFactor;
  static double get buttonHeightLarge => 56 * scaleFactor;

  /// Responsive border radius
  static double get radiusSmall => 4 * scaleFactor;
  static double get radiusNormal => 8 * scaleFactor;
  static double get radiusMedium => 12 * scaleFactor;
  static double get radiusLarge => 16 * scaleFactor;

  /// Responsive spacing
  static double get spaceXSmall => 4 * scaleFactor;
  static double get spaceSmall => 8 * scaleFactor;
  static double get spaceNormal => 16 * scaleFactor;
  static double get spaceLarge => 24 * scaleFactor;
  static double get spaceXLarge => 32 * scaleFactor;

  /// Responsive heights for common widgets
  static double get appBarHeight => 56 * scaleFactor;
  static double get extendedAppBarHeight => 120 * scaleFactor;
  static double get tabBarHeight => 48 * scaleFactor;
  static double get toolbarHeight => 56 * scaleFactor;
  static double get bottomNavBarHeight => 60 * scaleFactor;

  /// Check screen orientation
  static bool get isPortrait => screenHeight > screenWidth;
  static bool get isLandscape => screenWidth > screenHeight;

  /// Responsive width for columns/cards
  static double getResponsiveWidth({
    required double minWidth,
    double maxWidth = double.infinity,
  }) {
    final width = screenWidth * 0.9;
    return width.clamp(minWidth, maxWidth);
  }

  /// Responsive grid count for GridView
  static int getGridCount({
    int minItemsPerRow = 2,
    int maxItemsPerRow = 4,
  }) {
    if (screenWidth < 600) return minItemsPerRow;
    if (screenWidth < 1000) return 2 + (minItemsPerRow - 1);
    return maxItemsPerRow;
  }

  /// Device safe padding (notch/cutout)
  static EdgeInsets get deviceSafePadding => _mediaQuery.padding;
  static EdgeInsets get deviceViewInsets => _mediaQuery.viewInsets;
}

/// Extension methods for responsive sizing
extension ResponsiveExtension on num {
  /// Convert value to responsive size
  double get resp => this * ResponsiveUtils.scaleFactor;
}
